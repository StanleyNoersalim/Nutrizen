import Prediction from "../components/Prediction";
import Title from "../components/Title";

export default function Home() {

    return (
        <div>
            <Title />
            <Prediction />
        </div>
    );
}
